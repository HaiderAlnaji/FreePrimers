"""
Fetch a genomic region sequence by gene name or by coordinate range (Ensembl).
For the methylation tab: a user gives a gene symbol (e.g. "BRCA2"), an Ensembl
gene id, or a coordinate range ("13:32315000-32316000"), and we return the
reference sequence so they can design bisulfite assays over a promoter/exon.

Network required; returns an object with ok/error so the UI can show why a
lookup failed instead of a generic message.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

try:
    import requests
except ImportError:
    requests = None

ENSEMBL = "https://rest.ensembl.org"


@dataclass
class RegionFetchResult:
    ok: bool = False
    query: str = ""
    sequence: str = ""
    region: str = ""          # resolved "chr:start-end"
    gene: str = ""
    assembly: str = ""
    note: str = ""
    error: str = ""


def _fail(q, msg):
    return RegionFetchResult(ok=False, query=q, error=msg)


def _looks_like_region(q: str) -> bool:
    # e.g. 13:32315000-32316000  or  13:32315000..32316000
    import re
    return bool(re.match(r"^[\dXYMT]+:\d+[-.]+\d+$", q.strip()))


def fetch_region(query: str, species: str = "human", flank: int = 0,
                 max_len: int = 4000) -> RegionFetchResult:
    query = (query or "").strip()
    if not query:
        return _fail(query, "No gene or region given.")
    if requests is None:
        return _fail(query, "The 'requests' library is not installed on the backend.")

    region = None
    gene_name = ""
    assembly = ""

    if _looks_like_region(query):
        region = query.replace("..", "-")
    else:
        # treat as a gene symbol or Ensembl id -> look up its coordinates
        try:
            g = requests.get(f"{ENSEMBL}/lookup/symbol/{species}/{query}",
                             params={"content-type": "application/json"},
                             headers={"Content-Type": "application/json"}, timeout=20)
            if g.status_code == 404:
                # maybe it's an Ensembl stable id
                g = requests.get(f"{ENSEMBL}/lookup/id/{query}",
                                 params={"content-type": "application/json"},
                                 headers={"Content-Type": "application/json"}, timeout=20)
            if g.status_code != 200:
                return _fail(query, f"Gene '{query}' not found in Ensembl (HTTP {g.status_code}).")
            gj = g.json()
            chrom = gj.get("seq_region_name")
            start = int(gj.get("start"))
            end = int(gj.get("end"))
            gene_name = gj.get("display_name", query)
            assembly = gj.get("assembly_name", "")
            # for methylation we usually want the PROMOTER / 5' region: take the
            # first ~1500 bp from the TSS-side, but cap to max_len.
            strand = int(gj.get("strand", 1))
            span = min(max_len, end - start + 1)
            if strand == 1:
                rs, re_ = start - flank, start + span - 1
            else:
                rs, re_ = end - span + 1, end + flank
            region = f"{chrom}:{rs}-{re_}"
        except Exception as e:
            return _fail(query, f"Gene lookup failed: {e}")

    # fetch the sequence for the resolved region
    try:
        s = requests.get(f"{ENSEMBL}/sequence/region/{species}/{region}",
                         params={"content-type": "application/json"},
                         headers={"Content-Type": "application/json"}, timeout=25)
        if s.status_code != 200:
            return _fail(query, f"Sequence fetch failed for {region} (HTTP {s.status_code}).")
        seq = s.json().get("seq", "").upper()
        if not seq:
            return _fail(query, f"Empty sequence returned for {region}.")
        if len(seq) > max_len:
            seq = seq[:max_len]
            note = f"Sequence truncated to {max_len} bp."
        else:
            note = ""
        return RegionFetchResult(ok=True, query=query, sequence=seq, region=region,
                                 gene=gene_name, assembly=assembly, note=note)
    except Exception as e:
        return _fail(query, f"Sequence fetch error: {e}")
