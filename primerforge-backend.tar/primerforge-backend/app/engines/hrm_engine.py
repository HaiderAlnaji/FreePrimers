"""
HRM (High Resolution Melting) primer design engine for SNP genotyping.

Two modes:

  STANDARD HRM (amplicon melt): a single primer pair flanking the SNP, producing
    a SHORT amplicon (typically 60-120 bp). Genotypes are distinguished by the
    melt curve of the whole amplicon — heterozygotes form heteroduplexes that
    melt differently, and the two homozygotes differ by the SNP's effect on
    amplicon Tm. Design goals: short amplicon, SNP roughly central, balanced
    primer Tm, primers NOT overlapping the SNP.

  ALLELE-SPECIFIC HRM (AS-HRM): allele-specific primers (3' end on the SNP, like
    ARMS) combined with an HRM readout. Two reactions (one per allele) or a
    single reaction where the allele-specific product's melt identifies the
    genotype. Here we design the AS primer pair sharing a common reverse primer,
    with the discriminating base at the 3' terminus and a deliberate -2 mismatch
    to boost specificity (same kinetic logic as ARMS).

The standard mode is the usual "HRM genotyping"; AS-HRM is used when allele
discrimination by amplicon melt alone is too subtle (e.g. class IV SNPs A/T or
C/G that barely shift Tm).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

COMP = {"A": "T", "T": "A", "C": "G", "G": "C", "N": "N"}


def revcomp(s: str) -> str:
    return "".join(COMP.get(b, "N") for b in reversed(s.upper()))


def tm_basic(seq: str) -> float:
    seq = seq.upper()
    n = len(seq)
    if n == 0:
        return 0.0
    gc = seq.count("G") + seq.count("C")
    if n < 14:
        return 2 * (n - gc) + 4 * gc
    return 64.9 + 41 * (gc - 16.4) / n


def gc_pct(seq: str) -> float:
    seq = seq.upper()
    return 100.0 * (seq.count("G") + seq.count("C")) / len(seq) if seq else 0.0


# SNP class by Tm-shift difficulty for amplicon HRM (Venter/Reja HRM class scheme):
#   Class 1: C/T, G/A (easy)    Class 2: C/A, G/T
#   Class 3: C/G (hard)         Class 4: A/T (hardest, near-zero Tm shift)
def snp_hrm_class(a1: str, a2: str) -> int:
    s = {a1.upper(), a2.upper()}
    if s in ({"C", "T"}, {"G", "A"}):
        return 1
    if s in ({"C", "A"}, {"G", "T"}):
        return 2
    if s == {"C", "G"}:
        return 3
    if s == {"A", "T"}:
        return 4
    return 2


@dataclass
class Primer:
    seq: str
    start: int
    end: int
    strand: str
    tm: float
    gc: float
    role: str = ""
    note: str = ""


@dataclass
class HrmDesign:
    mode: str
    primers: list = field(default_factory=list)
    amplicon: Optional[dict] = None
    snp_class: int = 0
    warnings: list = field(default_factory=list)
    notes: list = field(default_factory=list)


# ----------------------------------------------------------------- standard HRM
def design_standard_hrm(sense: str, snp_index: int, a1: str, a2: str,
                        tm_target: float = 60.0, len_lo: int = 18, len_hi: int = 25,
                        amp_lo: int = 60, amp_hi: int = 120) -> HrmDesign:
    """One primer pair flanking the SNP, short amplicon, SNP not under a primer."""
    sense = sense.upper()
    n = len(sense)
    d = HrmDesign(mode="standard-hrm", snp_class=snp_hrm_class(a1, a2))

    best = None
    best_sc = 1e9
    # forward primer ends before the SNP; reverse starts after it; amplicon short
    for fend in range(max(len_lo, snp_index - amp_hi // 2), snp_index - 5):
        for Lf in range(len_lo, len_hi + 1):
            fstart = fend - Lf
            if fstart < 0:
                continue
            fwd = sense[fstart:fend]
            for rstart in range(snp_index + 6, min(n, snp_index + amp_hi // 2)):
                amp_size = rstart - fstart
                if not (amp_lo <= amp_size <= amp_hi):
                    continue
                for Lr in range(len_lo, len_hi + 1):
                    rend = rstart + Lr
                    if rend > n:
                        continue
                    rev = revcomp(sense[rstart:rend])
                    # SNP must be strictly between the primers
                    if not (fend <= snp_index < rstart):
                        continue
                    tmf, tmr = tm_basic(fwd), tm_basic(rev)
                    sc = (abs(tmf - tm_target) + abs(tmr - tm_target)
                          + abs(tmf - tmr) * 1.5 + amp_size * 0.02)
                    if sc < best_sc:
                        best_sc = sc
                        best = (Primer(fwd, fstart, fend, "fwd", round(tmf, 1), round(gc_pct(fwd), 0), "HRM forward"),
                                Primer(rev, rstart, rend, "rev", round(tmr, 1), round(gc_pct(rev), 0), "HRM reverse"),
                                amp_size)
    if not best:
        d.warnings.append("Could not place a flanking pair with a 60-120 bp amplicon. "
                          "Provide more flanking sequence around the SNP.")
        return d
    fwd, rev, amp = best
    d.primers = [fwd, rev]
    d.amplicon = {"start": fwd.start, "end": rev.end, "size": amp,
                  "snp_offset_in_amplicon": snp_index - fwd.start}
    d.notes.append(f"Short {amp} bp amplicon with the SNP centred; genotypes "
                  "resolved by amplicon melt curve.")
    if d.snp_class >= 3:
        d.warnings.append(f"This is a class {d.snp_class} SNP ({a1}/{a2}) — "
                         f"{'C/G' if d.snp_class==3 else 'A/T'} substitutions cause a very "
                         "small amplicon Tm shift between homozygotes. Standard HRM may "
                         "not resolve the two homozygotes (heterozygotes still detectable "
                         "via heteroduplex). Consider allele-specific HRM instead.")
    else:
        d.notes.append(f"Class {d.snp_class} SNP ({a1}/{a2}) — well suited to amplicon HRM.")
    return d


# ----------------------------------------------------------------- allele-specific HRM
def design_as_hrm(sense: str, snp_index: int, a1: str, a2: str,
                  tm_target: float = 60.0, len_lo: int = 18, len_hi: int = 26,
                  amp_lo: int = 50, amp_hi: int = 150) -> HrmDesign:
    """Allele-specific forward primers (3' on the SNP, deliberate -2 mismatch)
    sharing a common reverse primer; HRM reads out which allele amplified.
    """
    sense = sense.upper()
    n = len(sense)
    d = HrmDesign(mode="as-hrm", snp_class=snp_hrm_class(a1, a2))

    def as_forward(allele, L):
        # forward primer 3' terminal base = allele; -2 position deliberate mismatch
        start = snp_index - L + 1
        if start < 0:
            return None
        body = sense[start:snp_index - 1]
        m2_genomic = sense[snp_index - 1]
        # deliberate -2 mismatch: pick a transversion vs the genomic -2 base
        m2 = {"A": "C", "C": "A", "G": "T", "T": "G"}.get(m2_genomic, "A")
        seq = body + m2 + allele
        return seq, start

    # common reverse primer downstream
    rev_best, rev_sc = None, 1e9
    for rstart in range(snp_index + amp_lo // 2, min(n, snp_index + amp_hi)):
        for Lr in range(len_lo, len_hi + 1):
            rend = rstart + Lr
            if rend > n:
                continue
            rev = revcomp(sense[rstart:rend])
            sc = abs(tm_basic(rev) - tm_target)
            if sc < rev_sc:
                rev_sc = sc
                rev_best = Primer(rev, rstart, rend, "rev", round(tm_basic(rev), 1),
                                  round(gc_pct(rev), 0), "common reverse")
    if not rev_best:
        d.warnings.append("Could not place a common reverse primer. Provide more 3' flank.")
        return d

    for allele, label in ((a1, f"allele {a1}"), (a2, f"allele {a2}")):
        best, sc = None, 1e9
        for L in range(len_lo, len_hi + 1):
            r = as_forward(allele, L)
            if not r:
                continue
            seq, start = r
            s = abs(tm_basic(seq) - tm_target)
            if s < sc:
                sc = s
                best = Primer(seq, start, snp_index + 1, "fwd", round(tm_basic(seq), 1),
                              round(gc_pct(seq), 0), f"AS forward · {label}",
                              note="3' terminal base is the allele; -2 deliberate mismatch")
        if best:
            d.primers.append(best)
    d.primers.append(rev_best)
    # amplicon span: allele-specific forward primer 5' start -> common reverse 3' end
    fwd_starts = [p.start for p in d.primers if p.strand == "fwd"]
    if fwd_starts:
        amp_start = min(fwd_starts)
        d.amplicon = {"start": amp_start, "end": rev_best.end,
                      "size": rev_best.end - amp_start,
                      "snp_offset_in_amplicon": snp_index - amp_start}
    d.notes.append("Allele-specific forward primers (3' on the SNP, ARMS-style "
                   "kinetic discrimination) with a shared reverse primer; HRM melt "
                   "of the product confirms which allele amplified. Useful for class "
                   "3-4 SNPs (C/G, A/T) where amplicon-melt HRM alone cannot resolve "
                   "the homozygotes.")
    return d


# ----------------------------------------------------------------- melt prediction
import math as _math


_NN_DH = {  # SantaLucia 1998 unified NN enthalpy (kcal/mol)
    "AA": -7.9, "TT": -7.9, "AT": -7.2, "TA": -7.2, "CA": -8.5, "TG": -8.5,
    "GT": -8.4, "AC": -8.4, "CT": -7.8, "AG": -7.8, "GA": -8.2, "TC": -8.2,
    "CG": -10.6, "GC": -9.8, "GG": -8.0, "CC": -8.0}
_NN_DS = {  # entropy (cal/mol/K)
    "AA": -22.2, "TT": -22.2, "AT": -20.4, "TA": -21.3, "CA": -22.7, "TG": -22.7,
    "GT": -22.4, "AC": -22.4, "CT": -21.0, "AG": -21.0, "GA": -22.2, "TC": -22.2,
    "CG": -27.2, "GC": -24.4, "GG": -19.9, "CC": -19.9}


def _amplicon_tm(seq: str, na: float = 0.0625, conc: float = 2.5e-7) -> float:
    """Amplicon melting temperature by the nearest-neighbour model (SantaLucia
    1998) with salt correction — NOT the bulk %GC formula.

    Why NN rather than the Wetmur %GC equation: the bulk formula sees only GC
    *count*, so it returns the SAME melt for every sequence of equal length/GC
    and the SAME single-base shift for every SNP of a given class — a GC-count
    artifact, not real melting. The NN model sums per-dinucleotide enthalpy and
    entropy, so sequence CONTEXT matters: different amplicons give genuinely
    different Tms, and a SNP's effect depends on its flanking bases, matching how
    real HRM behaves. (Full uMELT/POLAND statistical-mechanics melting is more
    accurate still; this is a solid mid-level model, labelled predicted.)
    """
    seq = seq.upper()
    if len(seq) < 2:
        return 0.0
    dH = 0.2
    dS = -5.7
    for i in range(len(seq) - 1):
        nn = seq[i:i + 2]
        if nn in _NN_DH:
            dH += _NN_DH[nn]
            dS += _NN_DS[nn]
    dS += 0.368 * (len(seq) - 1) * _math.log(na)
    denom = dS + 1.987 * _math.log(conc / 4.0)
    if denom == 0:
        return 0.0
    return (1000.0 * dH) / denom - 273.15


def predict_melt_curves(amplicon_seq: str, snp_offset: int, a1: str, a2: str,
                        t_lo: float = None, t_hi: float = None, step: float = 0.2):
    """Predicted HRM curves for the three genotypes (homozygous a1/a1, a2/a2,
    heterozygous). SIMPLIFIED two-state model for ILLUSTRATION — not real
    instrument data and not full statistical-mechanics melting.

    Returns dict with temperature axis and three normalised fluorescence traces
    plus their difference curves (-dF/dT), and the predicted Tm of each.
    """
    seq = amplicon_seq.upper()
    # build the two homozygous amplicons (a1 and a2 at the SNP)
    amp1 = seq[:snp_offset] + a1 + seq[snp_offset + 1:]
    amp2 = seq[:snp_offset] + a2 + seq[snp_offset + 1:]
    tm1, tm2 = _amplicon_tm(amp1), _amplicon_tm(amp2)
    # heteroduplex: a mismatch destabilises -> melts lower than either homoduplex.
    mismatch = {a1, a2}
    drop = 1.5
    if mismatch == {"A", "T"} or mismatch == {"C", "G"}:
        drop = 1.0
    het_tm = min(tm1, tm2) - drop
    # auto-frame the temperature window around the predicted Tms (realistic HRM
    # melts ~75-90 C; window spans a few C either side of the actual Tms here)
    tms = [tm1, tm2, het_tm]
    if t_lo is None:
        t_lo = round(min(tms) - 8)
    if t_hi is None:
        t_hi = round(max(tms) + 5)

    def trace(tm, width=1.6):
        xs, ys = [], []
        t = t_lo
        while t <= t_hi + 1e-9:
            xs.append(round(t, 2))
            ys.append(1.0 / (1.0 + _math.exp((t - tm) / width)))
            t += step
        return xs, ys

    def deriv(xs, ys):
        d = [0.0]
        for i in range(1, len(ys)):
            d.append(-(ys[i] - ys[i - 1]) / (xs[i] - xs[i - 1]))
        # normalise to peak 1.0
        mx = max(d) or 1.0
        return [round(v / mx, 4) for v in d]

    xs, y1 = trace(tm1)
    _, y2 = trace(tm2)
    _, yh = trace(het_tm)
    # heterozygote observed melt = average of its two homoduplexes + heteroduplexes
    y_het = [round((a + b + 2 * c) / 4, 4) for a, b, c in zip(y1, y2, yh)]
    return {
        "temperature": xs,
        "melt": {
            f"{a1}/{a1}": [round(v, 4) for v in y1],
            f"{a2}/{a2}": [round(v, 4) for v in y2],
            f"{a1}/{a2}": y_het,
        },
        "difference": {
            f"{a1}/{a1}": deriv(xs, y1),
            f"{a2}/{a2}": deriv(xs, y2),
            f"{a1}/{a2}": deriv(xs, y_het),
        },
        "tm": {f"{a1}/{a1}": round(tm1, 2), f"{a2}/{a2}": round(tm2, 2),
               f"{a1}/{a2}": round(het_tm, 2)},
        "model": "Simplified two-state sigmoid melt (predicted, illustrative — "
                 "not real instrument data; not full statistical-mechanics melting). "
                 "Absolute Tm is salt/GC-dependent and approximate; the Tm "
                 "DIFFERENCES between genotypes are the meaningful readout.",
    }
