import PrimerStudio from './PrimerStudio.jsx'

export default function App() {
  return <PrimerStudio />
}
