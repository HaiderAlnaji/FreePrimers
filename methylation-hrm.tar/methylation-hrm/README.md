# Methylation + HRM primer design engines

Two new engines for Primer Studio.

## Methylation (methylation_engine.py)
Bisulfite-based assays. Core rule: unmethylated C -> T after conversion;
methylated C (CpG context) stays C. Three modes:
  - MSP: methylated + unmethylated primer SETS that COVER CpGs (discriminate state)
  - BSP: one pair that AVOIDS CpGs (amplifies both states; read by sequencing)
  - MS-HRM: BSP-style CpG-free primers around a CpG-rich short amplicon; methylated
    vs unmethylated amplicons differ in Tm (reported), resolved by HRM.

## HRM (hrm_engine.py)
SNP genotyping by melt. Two modes:
  - Standard HRM: one flanking pair, short amplicon, genotype by amplicon melt.
    Reports SNP HRM class (1 easy C/T,G/A ... 4 hardest A/T) and warns when the
    class is too hard for amplicon-melt resolution.
  - Allele-specific HRM: ARMS-style AS forward primers (3' on SNP, -2 mismatch) +
    shared reverse; for class 3-4 SNPs where amplicon melt can't resolve homozygotes.

## Honest limitations
  - Tm uses a basic GC/Wallace estimate (bisulfite primers are low-GC; nearest-
    neighbour via the backend is more accurate and used when connected).
  - Designs are computational; always validate empirically.
  - MSP/BSP designed on the top converted strand; bottom-strand designs need the
    reverse complement of the input region.
  - No wet-lab validation.
