#!/usr/bin/env python3
import argparse, sys
import methylation_engine as me
def read_fa(p):
    s=[]
    for ln in open(p):
        if ln.startswith('>') or not ln.strip(): continue
        s.append(ln.strip())
    return ''.join(s)
ap=argparse.ArgumentParser()
ap.add_argument('--fasta',required=True); ap.add_argument('--mode',choices=['msp','bsp','mshrm'],required=True)
a=ap.parse_args()
seq=read_fa(a.fasta)
if a.mode=='msp':
    r=me.design_msp(seq)
    for st in ('methylated','unmethylated'):
        print(st); [print(' ',p.role,p.seq,'Tm',p.tm) for p in r[st].primers]
elif a.mode=='bsp':
    d=me.design_bsp(seq); [print(p.role,p.seq,'Tm',p.tm) for p in d.primers]; print('amp',d.amplicon)
    [print('!',w) for w in d.warnings]
else:
    d=me.design_mshrm(seq); [print(p.role,p.seq,'Tm',p.tm) for p in d.primers]; print('amp',d.amplicon)
    [print('!',w) for w in d.warnings]
